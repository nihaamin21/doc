<?php /* Template Name: About us */
get_header(); ?>

<section>
    <div class="about-us">
        <h2 class="heading"><span class="badge badge-light">ABOUT US</span></h2>


        <div class="about">
            Building a website is, in many ways, an exercise of willpower. It’s tempting to get distracted
            the bells and whistles of the design process, and forget all about creating compelling content.
            It's that compelling content that's crucial to making inbound marketing work for your business.
        </div>
    </div>
    <div class="container">
        <div class="row-2">
            <div class="card" id="card-1">
                <img class="card-img-top" src="<?php echo get_bloginfo('template_url'); ?>/images/p.jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">Some quick example text to build on the card title and make up the
                        bulk of
                        the card's content.</p>
                </div>
            </div>
            <div class="card" id="card-2">
                <img class="card-img-top" src="<?php echo get_bloginfo('template_url'); ?>/images/h.jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">Some quick example text to build on the card title and make up the
                        bulk of
                        the card's content.</p>
                </div>
            </div>
            <div class="card" id="card-3">
                <img class="card-img-top" src="<?php echo get_bloginfo('template_url'); ?>/images/t.jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">Some quick example text to build on the card title and make up the
                        bulk of
                        the card's content.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>