<!-- Footer Starts -->
<div class="card-footer">

    <div class="container">

        <div class="row">
            <?php dynamic_sidebar( 'Footer Copyright' ); ?>
        </div>
        <div class="row">
            <?php dynamic_sidebar( 'Footer Social' ); ?>
        </div>
    </div>
</div>
</main>
</body>

</html>